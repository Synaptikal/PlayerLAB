# PlayerLAB
Fantasy Football News Analytics Highlights and Hype

## Quick Save Setup ✅
- Run `./quick-save.sh` or `save` to instantly commit and push all changes to GitHub
- Every edit is automatically saved with timestamp
- No work will be lost!
